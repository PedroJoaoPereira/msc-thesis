cuda
====

Just some examples of using CUDA I have put together
