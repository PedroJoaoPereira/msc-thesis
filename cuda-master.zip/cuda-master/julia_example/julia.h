#ifndef _JULIA_H_
#define _JULIA_H_

void julia_set(int width, int height, unsigned char *bitmap);

#endif